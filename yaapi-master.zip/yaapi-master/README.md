# Sample REST API project
This is a sample REST API project for the used car sample case. The project currently only implements the handling of GET requests to the /cars/{id} endpoint. Simple unit and API test are provided too.
