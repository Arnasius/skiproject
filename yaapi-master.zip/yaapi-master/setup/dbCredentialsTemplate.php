<?php
const DB_HOST = '127.0.0.1';
const DB_NAME = 'demotest';
const DB_USER = 'aUser';
const DB_PWD = '********';
